require('dotenv').config()
const express = require('express')
const bodyParser = require("body-parser");
const mongoose = require('mongoose');
const session = require('express-session');
const passport = require('passport');
const strtotime = require('strtotime');
const path = require('path');
const passportLocalMongoose = require('passport-local-mongoose');
const dateFormat = require('dateformat');
const deg2rad = require('deg2rad');
const rad2deg = require('rad2deg');
const sprintf = require('sprintf-js').sprintf;
const app = express()

const port = process.env.PORT || 3000; // Heroku will need the PORT environment variable

mongoose.connect('mongodb+srv://manishgupta:Danger%401234@forexblues.s2gfj.mongodb.net/forexblues', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

mongoose.set('useCreateIndex', true);


app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'build')));

app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname + '/build/index.html'));
});

app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    next();
})

const options = {
    inflate: true,
    limit: '100kb',
    type: 'application/octet-stream'
};
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());
app.use(bodyParser.raw(options));


app.use(session({
    secret: 'THISISTHETEMPORARYACCESSKEY',
    resave: false,
    saveUninitialized: true
}));

app.use(passport.initialize());
app.use(passport.session());

const userSchema = new mongoose.Schema({
    active: Boolean,
    user_level: Number,
    username: String,
    mobile: String,
    email: String,
    password: String,
    name: String,
    registration_date: String,
    profile_Image: String,
});


const leadSchema = new mongoose.Schema({
    status: String,
    fullName: String,
    companyName: String,
    address: String,
    city: String,
    state: String,
    email: String,
    mobile1: String,
    mobile2: String,
    agentName: String,
    businessType: String,
    businessVolume: String,
    source: String,
    comment: String,
    later: String,
    feedback: [{
        date: String,
        feedback: String,
        status: String,
        notes: String
    }]
});

const newLeadSchema = new mongoose.Schema({
    fullName: String,
    companyName: String,
    address: String,
    city: String,
    state: String,
    email: String,
    mobile1: String,
    mobile2: String,
    isTaken: String,
    agentName: String
});

userSchema.plugin(passportLocalMongoose);

const User = mongoose.model('User', userSchema);
const Lead = mongoose.model('Lead', leadSchema);
const NewLead = mongoose.model('NewLead', newLeadSchema);

// use static authenticate method of model in LocalStrategy
passport.use(User.createStrategy());

// use static serialize and deserialize of model for passport session support
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

//1 - Owner
//2 - Agents
//3 - Freelancer

app.post("/api/register", function (req, res) {

    const userLevel = req.body.userLevel;

    if (userLevel) {
        const user = {
            active: true,
            user_level: userLevel,
            username: req.body.username,
            registration_date: dateFormat(new Date(), "yyyy-mm-dd HH:MM:ss")
        }
        User.exists({
            username: user.username
        }, function (err, exists) {
            if (!exists) {
                User.register(user, req.body.password, function (err, user) {
                    if (err) {
                        const result = {
                            success: false,
                            name: err.name,
                            message: err.message
                        };
                        res.send(JSON.stringify(result));
                    } else {
                        User.find({
                            username: user.username
                        }, function (err, user) {
                            if (err) {
                                const result = {
                                    success: false,
                                    name: err.name,
                                    message: err.message
                                };
                                res.send(JSON.stringify(result));
                            } else {
                                passport.authenticate("local", {
                                    session: false
                                })(req, res, function () {
                                    const result = {
                                        success: true,
                                        data: user[0]
                                    };
                                    res.send(JSON.stringify(result));
                                });
                            }
                        });
                    }
                });
            } else {
                const result = {
                    success: false,
                    name: 'USERAlreadyExists',
                    message: 'This User already exists.'
                };
                res.send(JSON.stringify(result));
            }
        });
    } else {
        const result = {
            success: false,
            name: 'UserTypeError',
            message: 'A user type is required.'
        };
        res.send(JSON.stringify(result));
    }
});

app.post("/api/login", async function (req, res) {

    const user = User({
        username: req.body.username,
        password: req.body.password,
    });

    req.login(user, async function (err) {
        if (err) {
            const result = {
                success: false,
                name: err.name,
                message: err.message
            };
            res.send(JSON.stringify(result));
        } else {
            User.find({
                username: req.body.username
            }, async function (err, user) {
                if (err) {
                    const result = {
                        success: false,
                        name: err.name,
                        message: err.message
                    };
                    res.send(JSON.stringify(result));
                } else {
                    passport.authenticate("local")(req, res, function () {
                        const result = {
                            success: true,
                            data: user[0]
                        };
                        res.send(JSON.stringify(result));
                    });
                }
            });
        }
    });
});

app.post("/api/upload-new-lead", function (req, res) {
    const userID = req.body.userID;
    if (userID) {
        User.findById(userID, function (err, user) {
            if (!err) {
                if (user.user_level === 1 || user.user_level === 2) {
                    NewLead.exists({
                        companyName: req.body.companyName
                    }, function (err, exists) {
                        if (!exists) {
                            const newLeadModel = new NewLead({
                                fullName: req.body.fullName,
                                companyName: req.body.companyName,
                                address: req.body.address,
                                city: req.body.city,
                                state: req.body.state,
                                email: req.body.email,
                                mobile1: req.body.mobile1,
                                mobile2: req.body.mobile2,
                                isTaken: req.body.isTaken,
                                agentName: req.body.agentName
                            });
                            newLeadModel.save(function (err) {
                                if (!err) {
                                    const result = {
                                        success: true,
                                        message: 'Lead created successfully.'
                                    };
                                    res.send(JSON.stringify(result));
                                } else {
                                    console.log(err);
                                    const result = {
                                        success: false,
                                        name: 'InternalError',
                                        message: 'Some error occured while saving data'
                                    };
                                    res.send(JSON.stringify(result));

                                }

                            });
                        } else {
                            const result = {
                                success: false,
                                name: 'LEADAlreadyExists',
                                message: 'This Lead already exists.'
                            };
                            res.send(JSON.stringify(result));
                        }
                    });
                } else {
                    const result = {
                        success: false,
                        name: 'PermissionDenied',
                        message: 'You don\'t have enough permission.'
                    };
                    res.send(JSON.stringify(result));
                }
            } else {
                const result = {
                    success: false,
                    name: 'PermissionDenied',
                    message: 'ID with required permission not found.'
                };
                res.send(JSON.stringify(result));
            }
        });
    } else {
        const result = {
            success: false,
            name: 'AuthorizationError',
            message: 'Mandatory data was not provided.'
        };
        res.send(JSON.stringify(result));
    }
});


//1. Demo
//2. Email
//3. Dormant
//4. Unreachable
//5. Wrong Number
//6. Others
//7. Later
//8. Others
//9. Others
//10. Others
//11. Comment
//12. Others
//13. Converted

app.post("/api/upload-lead", function (req, res) {
    const userID = req.body.agentName;
    if (userID) {
        User.findById(userID, function (err, user) {
            if (!err) {
                Lead.exists({
                    email: req.body.email
                }, function (err, exists) {
                    if (!exists) {
                        const leadModel = new Lead({
                            status: req.body.status,
                            agentName: req.body.agentName,
                            businessType: req.body.businessType,
                            businessVolume: req.body.businessVolume,
                            source: req.body.source,
                            comment: req.body.comment,
                            later: req.body.later,
                            feedback: [{
                                date: req.body.date,
                                feedback: req.body.status,
                                status: req.body.status,
                                notes: req.body.notes
                            }],
                            fullName: req.body.fullName,
                            companyName: req.body.companyName,
                            address: req.body.address,
                            city: req.body.city,
                            state: req.body.state,
                            email: req.body.email,
                            mobile1: req.body.mobile1,
                            mobile2: req.body.mobile2,
                        });
                        leadModel.save(function (err) {
                            if (!err) {
                                const result = {
                                    success: true,
                                    message: 'Lead uploaded successfully.'
                                };
                                res.send(JSON.stringify(result));
                            } else {
                                console.log(err);
                                const result = {
                                    success: false,
                                    name: 'InternalError',
                                    message: 'Some error occured while saving data'
                                };
                                res.send(JSON.stringify(result));

                            }

                        });
                    } else {
                        const result = {
                            success: false,
                            name: 'USERAlreadyExists',
                            message: 'This Lead already exists.'
                        };
                        res.send(JSON.stringify(result));
                    }
                });
            } else {
                const result = {
                    success: false,
                    name: 'PermissionDenied',
                    message: 'ID with required permission not found.'
                };
                res.send(JSON.stringify(result));
            }
        });
    } else {
        const result = {
            success: false,
            name: 'AuthorizationError',
            message: 'Mandatory data was not provided.'
        };
        res.send(JSON.stringify(result));
    }
});

app.post("/api/update-lead", function (req, res) {
    const userID = req.body.agentName;
    const leadID = req.body.leadID;
    if (userID) {
        User.findById(userID, function (err, user) {
            if (!err) {
                Lead.exists({
                    email: req.body.email
                }, function (err, exists) {
                    if (exists) {
                        Lead.findByIdAndUpdate(leadID, {
                            status: req.body.status,
                            agentName: req.body.agentName,
                            businessType: req.body.businessType,
                            businessVolume: req.body.businessVolume,
                            source: req.body.source,
                            comment: req.body.comment,
                            later: req.body.later,
                            $push: {
                                feedback: {
                                    date: req.body.date,
                                    feedback: req.body.status,
                                    status: req.body.status,
                                    notes: req.body.notes
                                }
                            },
                            fullName: req.body.fullName,
                            companyName: req.body.companyName,
                            address: req.body.address,
                            city: req.body.city,
                            state: req.body.state,
                            email: req.body.email,
                            mobile1: req.body.mobile1,
                            mobile2: req.body.mobile2,
                        }, function (err, item) {
                            if (!err) {
                                const result = {
                                    success: true,
                                    message: 'Lead updated successfully.'
                                };
                                res.send(JSON.stringify(result));
                            } else {
                                console.log(err);
                                const result = {
                                    success: false,
                                    name: 'InternalError',
                                    message: 'Some error occured while saving data'
                                };
                                res.send(JSON.stringify(result));

                            }

                        });
                    } else {
                        const result = {
                            success: false,
                            name: 'USERAlreadyExists',
                            message: 'This Lead already exists.'
                        };
                        res.send(JSON.stringify(result));
                    }
                });
            } else {
                const result = {
                    success: false,
                    name: 'PermissionDenied',
                    message: 'ID with required permission not found.'
                };
                res.send(JSON.stringify(result));
            }
        });
    } else {
        const result = {
            success: false,
            name: 'AuthorizationError',
            message: 'Mandatory data was not provided.'
        };
        res.send(JSON.stringify(result));
    }
});

app.post("/api/user-leads", function (req, res) {
    const agentName = req.body.userID;
    const status = req.body.status;
    Lead.find({ agentName: agentName, status: status }, async function (err, leads) {
        if (err) {
            const result = {
                success: false,
                name: err.name,
                message: err.message
            };
            res.send(JSON.stringify(result));
        } else {
            const result = {
                success: true,
                data: leads
            };
            res.send(JSON.stringify(result));
        }
    });
});

app.post("/api/new-leads", function (req, res) {
    const agentName = req.body.userID;
    NewLead.find({}, null, { limit: 70 }, async function (err, leads) {
        if (err) {
            const result = {
                success: false,
                name: err.name,
                message: err.message
            };
            res.send(JSON.stringify(result));
        } else {
            for (let i = 0; i < leads.length; i++) {
                await NewLead.findByIdAndDelete(leads[i]._id);
            }
            const result = {
                success: true,
                data: leads
            };
            res.send(JSON.stringify(result));
        }
    });
});

app.post("/api/master-search", function (req, res) {
    const query = req.body.query;
    Lead.findOne({
        $or: [
            { 'mobile1': query }, { 'mobile2': query }, { 'email': query }, { 'companyName': query }, { 'fullName': query }
        ]
    }, async function (err, leads) {
        if (err) {
            const result = {
                success: false,
                name: err.name,
                message: err.message
            };
            res.send(JSON.stringify(result));
        } else {
            const result = {
                success: true,
                data: leads
            };
            res.send(JSON.stringify(result));
        }
    });
});

app.post("/api/search", function (req, res) {
    const query = req.body.query;
    const agentName = req.body.userID;
    const status = req.body.status;
    Lead.findOne({
        agentName: agentName, status: status, $or: [
            { 'mobile1': query }, { 'mobile2': query }, { 'email': query }, { 'companyName': query }, { 'fullName': query }
        ]
    }, async function (err, leads) {
        if (err) {
            const result = {
                success: false,
                name: err.name,
                message: err.message
            };
            res.send(JSON.stringify(result));
        } else {
            const result = {
                success: true,
                data: leads
            };
            res.send(JSON.stringify(result));
        }
    });
});

app.post("/api/counts", function (req, res) {
    const agentName = req.body.userID;
    const status = req.body.status;
    Lead.countDocuments({ agentName: agentName, status: status }, function (err, count) {
        if (err) {
            const result = {
                success: false,
                error: err,
            };
            res.send(JSON.stringify(result));
        } else {
            const result = {
                success: true,
                lead: count,
            };
            res.send(JSON.stringify(result));
        }
    });
});

app.post("/api/counts-date-today", function (req, res) {
    const agentName = req.body.userID;
    const status = req.body.status;
    Lead.find({ agentName: agentName, status: status }, function (err, leads) {
        if (err) {
            const result = {
                success: false,
                error: err,
            };
            res.send(JSON.stringify(result));
        } else {
            let count = 0;
            for (let index = 0; index < leads.length; index++) {
                const element = leads[index].feedback[leads[index].feedback.length - 1];
                if (element.status == status) {
                    if(dateFormat(element.date, "yyyy-mm-dd") == dateFormat(new Date(), "yyyy-mm-dd"))
                    {
                        count++;
                    }
                }
            }
            const result = {
                success: true,
                lead: count,
            };
            res.send(JSON.stringify(result));
        }
    });
});

app.post("/api/counts-date-month", function (req, res) {
    const agentName = req.body.userID;
    const status = req.body.status;
    Lead.find({ agentName: agentName, status: status }, function (err, leads) {
        if (err) {
            const result = {
                success: false,
                error: err,
            };
            res.send(JSON.stringify(result));
        } else {
            let count = 0;
            for (let index = 0; index < leads.length; index++) {
                const element = leads[index].feedback[leads[index].feedback.length - 1];
                if (element.status == status) {
                    if(dateFormat(element.date, "yyyy-mm") == dateFormat(new Date(), "yyyy-mm"))
                    {
                        count++;
                    }
                }
            }
            const result = {
                success: true,
                lead: count,
            };
            res.send(JSON.stringify(result));
        }
    });
});

app.post("/api/counts-date-month-prev", function (req, res) {
    const agentName = req.body.userID;
    const status = req.body.status;
    Lead.find({ agentName: agentName, status: status }, function (err, leads) {
        if (err) {
            const result = {
                success: false,
                error: err,
            };
            res.send(JSON.stringify(result));
        } else {
            let count = 0;
            const current = new Date().setMonth(new Date().getMonth() - 1);
            for (let index = 0; index < leads.length; index++) {
                const element = leads[index].feedback[leads[index].feedback.length - 1];
                if (element.status == status) {
                    if(dateFormat(element.date, "yyyy-mm") == dateFormat(current, "yyyy-mm"))
                    {
                        count++;
                    }
                }
            }
            const result = {
                success: true,
                lead: count,
            };
            res.send(JSON.stringify(result));
        }
    });
});

app.post("/api/new-counts", function (req, res) {
    NewLead.count({}, function (err, count) {
        if (err) {
            const result = {
                success: false,
                error: err,
            };
            res.send(JSON.stringify(result));
        } else {
            const result = {
                success: true,
                lead: count,
            };
            res.send(JSON.stringify(result));
        }
    });
});

app.post("/api/status", function (req, res) {
    const result = {
        success: false,
        statusCode: 503,
    };
    res.send(JSON.stringify(result));

});

app.listen(port, function () {
    console.log("Server listening on port " + port);
});