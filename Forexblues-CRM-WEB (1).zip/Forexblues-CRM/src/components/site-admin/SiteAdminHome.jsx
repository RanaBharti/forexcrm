import React, { useEffect, useState } from "react";
import cookie from 'react-cookies';
import CustomAlert from './components/CustomAlert';
import CustomLabel from './components/CustomLabel';
import Spinner from "react-bootstrap/Spinner";
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import CreateAccountScreen from "./screens/CreateAccountScreen";
import UsersScreen from "./screens/UsersScreen";
import { FaMobileAlt, FaPlus, FaUserFriends } from 'react-icons/fa';
import { MdSignalCellular4Bar, MdSignalCellularNoSim } from 'react-icons/md';
import { GiElectricalResistance } from "react-icons/gi";
import Sidebar from "./components/CustomSidebar";
import CreateTrackerScreen from "./screens/CreateTrackerScreen";
import CreateSensorScreen from "./screens/CreateSensorScreen";
import CreateDeviceScreen from "./screens/CreateDeviceScreen";
import ViewAllDevicesScreen from "./screens/ViewAllDevicesScreen";
import ViewAllUsersScreen from "./screens/ViewAllUsersScreen";



const screens = [{ icon: <FaPlus className="sidebar-icon" />, name: 'New Lead', key: 'create_account' },
{ icon: <FaMobileAlt className="sidebar-icon" />, name: 'Demo', key: 'demo' },
{ icon: <MdSignalCellular4Bar className="sidebar-icon" />, name: 'Converted', key: 'converted' },
{ icon: <GiElectricalResistance className="sidebar-icon" />, name: 'Dormant', key: 'dormant' },
{ icon: <MdSignalCellularNoSim className="sidebar-icon" />, name: 'Unreachable', key: 'unreachable' },
{ icon: <FaMobileAlt className="sidebar-icon" />, name: 'Comment', key: 'comment' },
{ icon: <FaMobileAlt className="sidebar-icon" />, name: 'Wrong No.', key: 'wrong_no' },
{ icon: <FaMobileAlt className="sidebar-icon" />, name: 'Email', key: 'email' },
{ icon: <FaMobileAlt className="sidebar-icon" />, name: 'Others', key: 'others' },
{ icon: <FaMobileAlt className="sidebar-icon" />, name: 'Later', key: 'later' }];

const screensBottom = [
     { icon: <FaMobileAlt className="sidebar-icon" />, name: 'Master Search', key: 'master_search' },
     { icon: <FaMobileAlt className="sidebar-icon" />, name: 'Add New Lead', key: 'add_new_lead' },
     { icon: <FaPlus className="sidebar-icon" />, name: 'Profile', key: 'profile' }
];


const SiteAdminHome = props => {
     const [selectedScreen, setselectedScreen] = useState(<WelcomeScreen />);
     const [isExpanded, setIsExpanded] = useState(false);
     const [selectedScreenKey, setselectedScreenKey] = useState('welcome');
     const [width, setWidth] = useState(96);

     if ((cookie.load('Status', { doNotParse: true }) ?? false) === false) {
          props.history.replace('site-admin');
          return;
     }

     const handleToggler = () => {
          if (isExpanded) {
               requestAnimationFrame(() => {
                    setWidth(96);
               });

               setIsExpanded(false);
               return;
          }
          else {
               requestAnimationFrame(() => {
                    setWidth(85);
               });
               setIsExpanded(true);
          }
     }

     function handleSidebarClick(key) {
          setselectedScreenKey(key);
          switch (key) {
               case 'create_account': setselectedScreen(<AccountsScreen />);
                    break;
               case 'demo': setselectedScreen(<DeviceScreen status='1' />);
                    break;
               case 'email': setselectedScreen(<DeviceScreen status='2' />);
                    break;
               case 'dormant': setselectedScreen(<DeviceScreen status='3' />);
                    break;
               case 'unreachable': setselectedScreen(<DeviceScreen status='4' />);
                    break;
               case 'wrong': setselectedScreen(<DeviceScreen status='5' />);
                    break;
               case 'others': setselectedScreen(<DeviceScreen status='6' />);
                    break;
               case 'later': setselectedScreen(<DeviceScreen status='7' />);
                    break;
               case 'comment': setselectedScreen(<DeviceScreen status='8' />);
                    break;
               default: setselectedScreen(<WelcomeScreen />);
                    break;
          }
     }

     return <div style={{ backgroundColor: '#F0E5CF', height: '100%', width: '100%', }}>

          <div style={{ backgroundColor: '#F4F5F7', height: '92.5%', width: '85%', right: 0, position: 'absolute', top: '7.5%', display: 'flex', paddingLeft: '1%' }}>
               {selectedScreen}
          </div>

          <div style={{ backgroundColor: '#FFFFFF', height: '7.5%', width: '100%', position: 'absolute', left: 0, alignItems: 'center', display: 'flex', borderBottomRightRadius: '10px' }}>
               <img style={{ height: "60%", width: "auto", marginLeft: 10 }} src={process.env.PUBLIC_URL + '/images/colored_logo.png'} alt="dashboard_image" />
          </div>

          <Sidebar isExpanded={true} handleToggler={handleToggler} menu={screens} bottomMenu={screensBottom} onItemClick={handleSidebarClick} selectedKey={selectedScreenKey} widthState={width} />

     </div>;
}



const WelcomeScreen = props => {
     return <label style={{ fontSize: '22px', fontFamily: 'monospace', color: 'grey', textAlign: 'start' }}>
          Welcome, Manish<br />Please select a menu to begin.
     </label>;
}

const AccountsScreen = props => {

     const [alertInfo, setAlertInfo] = useState({ visibility: false, type: 'danger', message: 'Error: Email and password cannot be empty.' });



     function Timer(time, message, type) {
          setAlertInfo({ visibility: true, type: type, message: message });
          setInterval(() => {
               setAlertInfo({ visibility: false, type: type, message: '' });
          }, time);
     }

     return (<div style={{ width: '100%', height: '100%', backgroundColor: '#F4F5F7', }}>
          <CreateDeviceScreen Timer={Timer} />
          <CustomAlert info={alertInfo} />
     </div>);
}

const DeviceScreen = props => {

     const [addDevice, setAddDevice] = useState(false);
     const [alertInfo, setAlertInfo] = useState({ visibility: false, type: 'danger', message: 'Error: Email and password cannot be empty.' });

     function Timer(time, message, type) {
          setAlertInfo({ visibility: true, type: type, message: message });
          setInterval(() => {
               setAlertInfo({ visibility: false, type: type, message: '' });
          }, time);
     }

     return (<div style={{ width: '100%', height: '100%', backgroundColor: '#F4F5F7', }}>
          {addDevice ? <CreateDeviceScreen Timer={Timer} addDevice={setAddDevice} /> : <ViewAllDevicesScreen Timer={Timer} addDevice={setAddDevice} />}
          <CustomAlert info={alertInfo} />
     </div>);
}

const AddDeviceToUserScreen = props => {
     const [alertInfo, setAlertInfo] = useState({ visibility: false, type: 'danger', message: '' });

     const [labelText, setLabelText] = useState('Select User');
     const [userList, setUserList] = useState(null);
     const [deviceList, setDeviceList] = useState(null);
     const [userSelectedID, setUserSelected] = useState(null);

     const reload = false;

     function Timer(time, message, type) {
          setAlertInfo({ visibility: true, type: type, message: message });
          setInterval(() => {
               setAlertInfo({ visibility: false, type: type, message: '' });
          }, time);
     }

     function fetchAllUsers() {
          const requestOptions = {
               mode: 'cors',
               method: 'POST',
               headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Origin': 'http://165.232.176.240/' },
               body: new URLSearchParams({ adminID: (cookie.load('UserID', { doNotParse: true }) ?? '') })
          };
          fetch('http://165.232.176.240/api/admin-users', requestOptions)
               .then(function (response) {
                    if (response.statusText === 'Unauthorized') {
                         return 'Unauthorized';
                    }
                    else {
                         return response.json();
                    }
               }).then(function (result) {
                    setUserList(result);
               }).catch(function (params) {
                    setUserList([]);
                    Timer(7000, ' ' + params, false);
               });
     }

     function fetchAllDevices() {
          const requestOptions = {
               mode: 'cors',
               method: 'POST',
               headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Origin': 'http://165.232.176.240/' },
               body: new URLSearchParams({ adminID: (cookie.load('UserID', { doNotParse: true }) ?? '') })
          };
          fetch('http://165.232.176.240/api/admin-devices', requestOptions)
               .then(function (response) {
                    if (response.statusText === 'Unauthorized') {
                         return 'Unauthorized';
                    }
                    else {
                         return response.json();
                    }
               }).then(function (result) {
                    setDeviceList(result);
               }).catch(function (params) {
                    setDeviceList([]);
                    Timer(7000, ' ' + params, false);
               });
     }

     function handleAddDevice(imei) {
          const requestOptions = {
               mode: 'cors',
               method: 'POST',
               headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Origin': 'http://165.232.176.240/' },
               body: new URLSearchParams({ userID: (cookie.load('UserID', { doNotParse: true }) ?? ''), customerID: userSelectedID, imei: imei })
          };
          fetch('http://165.232.176.240/api/add-user-device', requestOptions)
               .then(function (response) {
                    if (response.statusText === 'Unauthorized') {
                         return 'Unauthorized';
                    }
                    else {
                         return response.json();
                    }
               }).then(function (result) {
                    if (result.success === true) {
                         Timer(7000, `Device added successfully`, result.success);
                         setUserSelected(null);
                    }
                    else {
                         Timer(7000, result.message, result.success);
                    }
               }).catch(function (params) {
                    setUserSelected(null);
                    Timer(7000, ' ' + params, false);
               });
     }

     useEffect(() => {
          fetchAllUsers();
          fetchAllDevices();
     }, [reload])

     return <div style={{ width: '100%', height: '100%', backgroundColor: '#ecf0f1', position: 'absolute', padding: '10%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>

          {userSelectedID === null ? (userList ? <div style={{ overflow: "scroll", width: '100%', height: '100%', position: 'absolute', padding: '1%' }}>
               <CustomLabel text={labelText} />
               <TableContainer component={Paper}>
                    <Table aria-label="simple table">
                         <TableHead>
                              <TableRow>
                                   <TableCell>User ID</TableCell>
                                   <TableCell>Username</TableCell>
                                   <TableCell>Email</TableCell>
                                   <TableCell>Expiry Date</TableCell>

                                   <TableCell>Active</TableCell>
                                   <TableCell>Actions</TableCell>
                              </TableRow>
                         </TableHead>
                         <TableBody>
                              {userList.map((element) => (
                                   <TableRow key={element._id}>

                                        <TableCell>{element._id}</TableCell>
                                        <TableCell component="th" scope="row">
                                             {element.username}
                                        </TableCell>
                                        <TableCell>{element.email}</TableCell>
                                        <TableCell>{element.registration_date}</TableCell>

                                        <TableCell>{element.active === true ? 'Yes' : 'No'}</TableCell>
                                        <TableCell onClick={() => {
                                             setLabelText(`Select device for ${element.email}`);
                                             setUserSelected(element._id);
                                        }} style={{ color: 'blue' }}>Select Device</TableCell>
                                   </TableRow>
                              ))}
                         </TableBody>
                    </Table>
               </TableContainer>
          </div> :
               <Spinner animation="border" role="status">
                    <span className="visually-hidden">Loading...</span>
               </Spinner>) :
               (deviceList ? <div style={{ overflow: "scroll", width: '100%', height: '100%', position: 'absolute', padding: '1%' }}>
                    <CustomLabel text={labelText} />
                    <TableContainer component={Paper}>
                         <Table aria-label="simple table">
                              <TableHead>
                                   <TableRow>
                                        <TableCell>Name</TableCell>
                                        <TableCell>IMEI</TableCell>
                                        <TableCell>Expiry Date</TableCell>
                                        <TableCell>Tracker Time</TableCell>
                                        <TableCell>Device</TableCell>
                                        <TableCell>Active</TableCell>
                                        <TableCell>Actions</TableCell>
                                   </TableRow>
                              </TableHead>
                              <TableBody>
                                   {deviceList.map((element) => (
                                        <TableRow key={element.name}>
                                             <TableCell component="th" scope="row">
                                                  {element.name}
                                             </TableCell>
                                             <TableCell>{element.imei}</TableCell>
                                             <TableCell>{element.object_expire_dt}</TableCell>
                                             <TableCell>{element.dt_tracker}</TableCell>
                                             <TableCell>{element.device}</TableCell>
                                             <TableCell>{element.active === true ? 'Yes' : 'No'}</TableCell>
                                             <TableCell onClick={() => {
                                                  handleAddDevice(element.imei);
                                             }} style={{ color: 'blue' }}>Add Device</TableCell>
                                        </TableRow>
                                   ))}
                              </TableBody>
                         </Table>
                    </TableContainer>
               </div> :
                    <Spinner animation="border" role="status">
                         <span className="visually-hidden">Loading...</span>
                    </Spinner>)}
          <CustomAlert info={alertInfo} />
     </div>
}

const ViewAllUnKnownDevicesScreen = props => {
     const [alertInfo, setAlertInfo] = useState({ visibility: false, type: 'danger', message: '' });

     const [unknownDeviceList, setUnKnownDeviceList] = useState(null);

     const reload = false;

     function Timer(time, message, type) {
          setAlertInfo({ visibility: true, type: type, message: message });
          setInterval(() => {
               setAlertInfo({ visibility: false, type: type, message: '' });
          }, time);
     }

     function fetchAllUnknownDevices() {
          const requestOptions = {
               mode: 'cors',
               method: 'POST',
               headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Origin': 'http://165.232.176.240/' },
               body: new URLSearchParams({ adminID: (cookie.load('UserID', { doNotParse: true }) ?? '') })
          };
          fetch('http://165.232.176.240/api/unused-device', requestOptions)
               .then(function (response) {
                    if (response.statusText === 'Unauthorized') {
                         return 'Unauthorized';
                    }
                    else {
                         return response.json();
                    }
               }).then(function (result) {
                    setUnKnownDeviceList(result);
               }).catch(function (params) {
                    setUnKnownDeviceList([]);
                    Timer(7000, ' ' + params, false);
               });
     }

     useEffect(() => {
          fetchAllUnknownDevices();
     }, [reload])

     return <div style={{ width: '100%', height: '100%', backgroundColor: '#ecf0f1', position: 'absolute', padding: '10%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>

          {unknownDeviceList ? <div style={{ overflow: "scroll", width: '100%', height: '100%', position: 'absolute', padding: '1%' }}>
               <CustomLabel text={'All Unknown Devices'} />
               <TableContainer component={Paper}>
                    <Table aria-label="simple table">
                         <TableHead>
                              <TableRow>
                                   <TableCell>IMEI</TableCell>
                                   <TableCell>Server Time</TableCell>
                                   <TableCell>IP</TableCell>
                                   <TableCell>Port</TableCell>
                                   <TableCell>Count</TableCell>
                                   <TableCell>Device</TableCell>
                              </TableRow>
                         </TableHead>
                         <TableBody>
                              {unknownDeviceList.sort((a, b) => b.dt_server > a.dt_server).reverse().map((element) => (
                                   <TableRow key={element.name}>
                                        <TableCell>{element.imei}</TableCell>
                                        <TableCell>{element.dt_server}</TableCell>
                                        <TableCell>{element.ip}</TableCell>
                                        <TableCell>{element.port}</TableCell>
                                        <TableCell>{element.count}</TableCell>
                                        <TableCell>{element.protocol}</TableCell>
                                   </TableRow>
                              ))}
                         </TableBody>
                    </Table>
               </TableContainer>
          </div> :
               <Spinner animation="border" role="status">
                    <span className="visually-hidden">Loading...</span>
               </Spinner>}
          <CustomAlert info={alertInfo} />
     </div>
}

export default SiteAdminHome;


//Name,email,mobile,active,login,monitor,edit,delete,