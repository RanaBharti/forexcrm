import React from "react";
import { Card, Form } from "react-bootstrap";
import Alert from "react-bootstrap/Alert";
import cookie from 'react-cookies'
import Spinner from "react-bootstrap/Spinner";



function SiteAdminLogin(props) {

     const [visibility, setVisibility] = React.useState(false);
     const [loading, setLoading] = React.useState(false);
     const [alertMessage, setAlertMessage] = React.useState('Error: Email and password cannot be empty.');
     const [email, setEmail] = React.useState('');
     const [password, setPassword] = React.useState('');


     if (cookie.load('Status', { doNotParse: true }) ?? false) {
          props.history.replace('admin-home');
     }

     function saveCookies(value) {
          cookie.save('Status', JSON.parse(value).status, {
               path: '/',
               secure: false
          })
          cookie.save('UserID', JSON.parse(value).userID, {
               path: '/',
               secure: false
          })
          cookie.save('Email', JSON.parse(value).email, {
               path: '/',
               secure: false
          })
          cookie.save('Admin', JSON.parse(value).admin, {
               path: '/',
               secure: false
          })
          cookie.save('AdminLevel', JSON.parse(value).adminLevel, {
               path: '/',
               secure: false
          })
          props.history.replace('admin-home');
     }

     function Timer(time, message) {
          setAlertMessage(message);
          setVisibility(true);
          setInterval(() => {
               setVisibility(false);
          }, time);
     }

     function handleLogin(e) {
          if (e) { // add?
               e.preventDefault();
               //      e.persist();
          }
          if (!email || !password) {
               Timer(5000, 'Email and Password cannot be empty.');
          }
          else {
               setLoading(true);
               const requestOptions = {
                    mode: 'cors',
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Origin': process.env.PUBLIC_URL },
                    body: new URLSearchParams({ username: email, password: password })
               };
               fetch('http://localhost:3000/api/login', requestOptions)
                    .then(function (response) {
                         if (response.statusText === 'Unauthorized') {
                              return 'Unauthorized';
                         }
                         else {
                              return response.json();
                         }
                    }).then(function (result) {
                         if (result === 'Unauthorized') {
                              setLoading(false);
                              Timer(7000, 'Kindly check your username and password.');
                         }
                         else {
                              if (result.data.active) {
                                   setLoading(false);
                                   saveCookies(JSON.stringify({ status: result.success, userID: result.data._id, adminLevel: result.data.user_level }));
                              }
                              else {
                                   setLoading(false);
                                   Timer(7000, 'Your account is deactive. Kindly contact support.');
                              }
                         }
                    }).catch(function (params) {
                         setLoading(false);
                         Timer(7000, ' ' + params);
                    });
          }
     }


     return <div style={{ backgroundColor: 'white', height: '100%', width: '100%', position: 'absolute', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Alert style={{ margin: "10px", position: "absolute", right: "0px", top: "0px" }} show={visibility} variant="danger">
               <Alert.Heading style={{ fontSize: "16px" }}>{alertMessage}</Alert.Heading>
          </Alert>
          <Card style={{ width: '40%', heigh: '50%', backgroundColor: '#ecf0f1', position: 'absolute' }}>
               <Card.Body>
                    <div style={{
                         display: 'flex', alignItems: 'center', justifyContent: 'center'
                    }}>
                         <img style={{
                              marginTop: "5px", marginBottom: "5px", height: "auto", width: "40%"
                         }} src={process.env.PUBLIC_URL + '/images/colored_logo.png'} alt="dashboard_image" /></div>
                    <Form>
                         <Form.Group onChange={function (element) {
                              setEmail(element.target.value);
                         }} type="text" value={email} className="mb-3" controlId="formBasicEmail">
                              <Form.Label>Username</Form.Label>
                              <Form.Control type="email" placeholder="Enter username" />
                         </Form.Group>
                         <Form.Group onChange={function (element) {
                              setPassword(element.target.value);
                         }} type="password" value={password} className="form-control" placeholder="Enter password" className="mb-3" controlId="formBasicPassword">
                              <Form.Label  >Password</Form.Label>
                              <Form.Control type="password" placeholder="Password" />
                         </Form.Group>
                         <button style={{ marginTop: "10px", border: "0", background: "linear-gradient(89.91deg, #B061D0 0.06%, #5535B8 102.14%)", borderRadius: "3px", width: "100%" }} type="submit" onClick={handleLogin} className="btn btn-primary btn-block">
                              {loading ? <Spinner animation="border" role="status">
                                   <span className="visually-hidden">Loading...</span>
                              </Spinner> : <h3 style={{ color: "white", marginTop: "10px", fontSize: "18px", fontFamily: "Poppins" }}>Sign In</h3>}
                         </button>
                    </Form>
               </Card.Body>
          </Card>
     </div>;
}

export default SiteAdminLogin;
