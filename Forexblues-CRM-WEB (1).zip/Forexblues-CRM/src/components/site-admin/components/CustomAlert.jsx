import React from "react";
import { Alert } from "react-bootstrap";

const CustomAlert = ({ info }) => {
     return <Alert style={{ margin: "10px", position: "absolute", right: "0px", top: "0px" }} show={info.visibility} variant={info.type === false ? 'danger' : 'success'}>
          <Alert.Heading style={{ fontSize: "16px", fontFamily: 'monospace' }}>{info.message}</Alert.Heading>
     </Alert>;
}
export default CustomAlert;