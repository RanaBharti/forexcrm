import React from 'react';
import {Form} from "react-bootstrap";

const CustomCheckbox = ({ label, onChange, checked }) => {
     return (<Form.Group className="mb-3" controlId="formBasicCheckbox">
          <Form.Check checked={checked}
               onChange={onChange} type="checkbox" label={label} />
     </Form.Group>);
}

export default CustomCheckbox;