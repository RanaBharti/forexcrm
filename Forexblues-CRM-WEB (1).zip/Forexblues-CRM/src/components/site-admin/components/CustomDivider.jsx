import React from 'react';
import './Divider.css';

const CustomDivider = () => {
     return (<div className={"divider"} />)
}

export default CustomDivider;