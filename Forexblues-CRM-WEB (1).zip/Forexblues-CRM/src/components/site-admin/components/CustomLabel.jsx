import React from "react";

const CustomLabel = ({ text }) => {
     return <label style={{ fontSize: '18px',letterSpacing:0.9, color: 'black', textAlign: 'start', marginBottom: '10px' }}>
          {text}
     </label>;
}

export default CustomLabel;