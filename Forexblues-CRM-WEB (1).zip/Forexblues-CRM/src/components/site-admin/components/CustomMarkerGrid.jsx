import React, { useState } from "react";
import { FormControl, Form, FormLabel } from "react-bootstrap";
import Gallery from 'react-grid-gallery';

const markers = ["car-sedan.png", "car-hatch.png", "car-pickup.png", "car-suv.png", "truck.png"];

const CustomMarkerGrid = ({ placeholder, onMarkerChange }) => {
     const [selectedMarker, setSelectedMarker] = useState(0);

     return <div ><Form.Group className="form-control" className="mb-3" controlId="formBasicPassword">
          <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, color: 'grey', textAlign: 'start', marginBottom: '5px', display: 'block' }}>{placeholder}</Form.Label>
          {markers.map((element, index) => {
               return <img key={element} onClick={() => {
                    setSelectedMarker(index);
                    onMarkerChange(markers[index]);

               }} style={{ height: "50px", width: "50px", borderRadius: '10px', marginLeft: '5px', marginRight: '5px', border: index === selectedMarker ? '2px solid blue' : '2px solid white' }} src={`http://165.232.176.240/marker/${element}`} alt="dashboard_image" />
          })}

     </Form.Group></div>;
}

export default CustomMarkerGrid;