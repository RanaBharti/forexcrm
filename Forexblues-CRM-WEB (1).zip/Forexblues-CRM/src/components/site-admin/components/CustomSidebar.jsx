import React, { useState } from 'react';
import { FaMobileAlt } from 'react-icons/fa';
import './Sidebar.css';

const Sidebar = ({ isExpanded, handleToggler, menu, onItemClick, selectedKey, widthState,bottomMenu }) => {
     return (<div className={isExpanded ? "Sidebar" : "Sidebar collapsed"}>
          <div className="sidebar-items" onMouseEnter={handleToggler} onMouseLeave={handleToggler}>
               {menu.map((screen) => <SideMenuElement selectedKey={selectedKey} name={screen.name} click={onItemClick} id={screen.key} icon={screen.icon} />)}
          </div>

          <div className="sidebar-items" onMouseEnter={handleToggler} onMouseLeave={handleToggler}>
          {bottomMenu.map((screen) => <SideMenuElement selectedKey={selectedKey} name={screen.name} click={onItemClick} id={screen.key} icon={screen.icon} />)}
          </div>

     </div>);
}

const SideMenuElement = ({ selectedKey, name, click, id, icon }) => {
     return <div onClick={() => { click(id) }} className={selectedKey === id ? "itemSel" : "item"}>
          <div style={{ width: 10, height: 10, backgroundColor: 'rgba(0, 0, 0, 0.4)', borderRadius: 10, marginLeft:10,marginRight:10}} />
          <span className="sidebar-text">{name}</span>
     </div>;
}

export default Sidebar;