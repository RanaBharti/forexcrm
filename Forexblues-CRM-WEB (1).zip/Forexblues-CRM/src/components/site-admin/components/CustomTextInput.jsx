import React from "react";
import { FormControl, Form, FormLabel } from "react-bootstrap";

const CustomTextInput = ({ placeholder, value, onTextChange, inputType }) => {
     return <Form.Group className="form-control" className="mb-3" controlId="formBasicPassword">
          <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, color: 'grey', textAlign: 'start', marginBottom: '5px' }}>{placeholder}</Form.Label>
          <Form.Control style={{ fontSize: '14px', letterSpacing: 0.75, color: 'black', textAlign: 'start', marginBottom: '10px' }} onChange={function (element) {
               onTextChange(element.target.value);
          }} type={inputType} value={value} placeholder={placeholder} />
     </Form.Group>;
}

export default CustomTextInput;