import React from 'react';

const GradientCard = props => {
     const rgb = [props.color1.substring(1, 3), props.color1.substring(3, 5), props.color1.substring(5, 7)];
     const color2 = `rgb(${rgb.map(c => (parseInt(c, 16) * 0.8)).join()})`;
     return (
          <div style={{
               width: '20%', height: '100px', background: `linear-gradient(${props.color1}, ${color2})`, borderRadius: 10,
          }} >{props.children}</div>
     );
}

export default GradientCard;