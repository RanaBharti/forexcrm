import React, { useState } from 'react';
import CustomLabel from "../components/CustomLabel";
import CustomCountryPicker from "../components/CustomCountryPicker";
import CustomAlert from '../components/CustomAlert';
import CustomButton from '../components/CustomButton';
import CustomTextInput from '../components/CustomTextInput';
import { Form } from 'react-bootstrap';
import cookie from 'react-cookies';
import { IoClose } from "react-icons/io5";
import { FaCross, FaWhatsapp } from "react-icons/fa";
import CustomCard from '../components/CustomCard';
import CustomDivider from '../components/CustomDivider';



const CreateAccountScreen = ({ Timer, addUser }) => {

     const [userInfo, setUserInfo] = useState({ username: '', mobile: '', email: '', password: '123456', userType: 1, name: '' });
     const [loading, setLoading] = useState(false);

     let userTypeList = [{}]


     switch ((cookie.load('AdminLevel', { doNotParse: true }) ?? '1')) {
          case '3':
               userTypeList = [{ value: 1, label: 'End User (Customer)' }, { value: 2, label: 'Admin User' }];
               break;
          case '4':
               userTypeList = [{ value: 1, label: 'End User (Customer)' }, { value: 2, label: 'Admin User' }, { value: 3, label: 'Admin for Distributer' }, { value: 4, label: 'Super Admin' }];
               break;
          default:
               userTypeList = [{ value: 1, label: 'End User (Customer)' }, { value: 2, label: 'Admin User' }];
               break;
     }

     function handleCreateAccount(e) {
          console.log(userInfo);
          if (e) { // add?
               e.preventDefault();
               //      e.persist();
          }
          if (!userInfo.username || !userInfo.email || !userInfo.password) {
               Timer(5000, 'Kindly fill all the fields.', false);
          }
          else {
               setLoading(true);
               const requestOptions = {
                    mode: 'cors',
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Origin': 'http://165.232.176.240/' },
                    body: new URLSearchParams({
                         username: userInfo.username,
                         mobile: userInfo.mobile, email: userInfo.email, name: userInfo.name, password: userInfo.password, createdby: (cookie.load('UserID', { doNotParse: true }) ?? ''), user_level: userInfo.userType
                    })
               };
               fetch('http://165.232.176.240/api/register', requestOptions)
                    .then(function (response) {
                         if (response.statusText === 'Unauthorized') {
                              return 'Unauthorized';
                         }
                         else {
                              return response.json();
                         }
                    }).then(function (result) {
                         if (result.success === true) {
                              setLoading(false);
                              Timer(7000, `User created successfully for ${userInfo.email}`, result.success);
                              setUserInfo({ username: '', mobile: '', email: '', password: '123456', userType: 1, name: '' });
                              addUser(false);
                         }
                         else {
                              setLoading(false);
                              Timer(7000, result.message, result.success);
                         }
                    }).catch(function (params) {
                         setLoading(false);
                         Timer(7000, ' ' + params, false);
                    });
          }
     }

     return <div style={{ width: '100%', height: '100%', backgroundColor: '#F4F5F7', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>

          <CustomCard>
               <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <CustomLabel text={'Create an account.'} />
                    <IoClose size={20} onClick={() => { addUser(false); }} class="center" style={{ marginLeft: 5, marginRight: 5 }} />
               </div>
               <CustomDivider />
               <Form style={{ color: 'black', textAlign: 'start', marginBottom: '10px' }}>
                    <CustomTextInput placeholder={'Enter Full Name'} value={userInfo.name} onTextChange={(value) => { setUserInfo((latestUserInfo) => { return { ...latestUserInfo, name: value } }); }} inputType={'name'} />
                    <CustomCountryPicker placeholder={'Enter WhatsApp Number or Mobile Number'} value={userInfo.username} onTextChange={(value) => { setUserInfo((latestUserInfo) => { return { ...latestUserInfo, username: value, mobile: value } }); }} >
                         Enter <FaWhatsapp class="center" /> WhatsApp Number or Mobile Number
                    </CustomCountryPicker>
                    <CustomTextInput placeholder={'Enter Email'} value={userInfo.email} onTextChange={(value) => { setUserInfo((latestUserInfo) => { return { ...latestUserInfo, email: value } }); }} inputType={'email'} />
                    {userInfo.userType !== 1 ? <CustomTextInput placeholder={'Enter Password'} value={userInfo.password} onTextChange={(value) => { setUserInfo((latestUserInfo) => { return { ...latestUserInfo, password: value } }); }} inputType={'password'} /> : null}
                    {userInfo.userType === 1 ? <label style={{
                         width: 'auto',
                         fontSize: '10px',
                         letterSpacing: 0.75,
                         color: 'grey',
                         display: 'block',
                         textAlign: 'center',
                         marginBottom: '10px',
                         marginTop: '10px'
                    }} >
                         The password for End User (Customer) is set default to (123456).
                    </label> : null}
                    <CustomButton onClick={handleCreateAccount} text={'Create Account'} loading={loading} />
               </Form>
          </CustomCard>
     </div >
}

export default CreateAccountScreen;