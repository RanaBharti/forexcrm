import React, { useEffect, useState } from "react";
import cookie from 'react-cookies';
import { Form } from "react-bootstrap";
import moment from "moment";
import CustomLabel from "../components/CustomLabel";
import CustomTextInput from "../components/CustomTextInput";
import { IoClose } from "react-icons/io5";
import CustomButton from "../components/CustomButton";
import CustomCard from "../components/CustomCard";
import CustomDivider from "../components/CustomDivider";
import CustomDropDown from "../components/CustomDropDown";
import CustomMultiDropDown from "../components/CustomMultiDropDown";
import CustomMarkerGrid from "../components/CustomMarkerGrid";
import dateFormat from "dateformat";


const CreateDeviceScreen = ({ Timer }) => {
     const [loading, setLoading] = useState(false);
     const [userList, setUserList] = useState([]);
     const [expiryDate, setExpiryDate] = useState('');
     const [plansList, setPlansList] = useState([]);
     const [source, setSource] = useState([
          { label: 'Calling', value: 'calling' },
          { label: 'Referral', value: 'referral' },
          { label: 'SMS', value: 'sms' },
          { label: 'Email', value: 'email' },
          { label: 'Social Media', value: 'social_media' },
          { label: 'Digital Marketing', value: 'digital_marketing' }

     ]);
     const [businessType, setBusinessType] = useState([
          { label: 'Exporter', value: 'exporter' },
          { label: 'Importer', value: 'importer' },
          { label: 'EXP & IMP Both', value: 'exp_imp' },
          { label: 'Money Changer', value: 'money_changer' },
          { label: 'Forex Trader', value: 'forex_trader' },
          { label: 'NRI/Individual', value: 'nri' },
          { label: 'Other', value: 'other' },

     ]);
     const [businessVolume, setBusinessVolume] = useState([
          { label: 'Below \$50k USD', value: '50k' },
          { label: 'Above \$1lakh USD', value: '1lakh' },
          { label: '\$2lakh USD', value: '2lakh' },
          { label: '\$4-5lakh USD', value: '4lakh' },
          { label: '\$10lakh+ USD', value: '10lakh' },
          { label: 'Did not disclose', value: 'did_not_disclose' }

     ]);

     const [feedback, setFeedback] = useState([
          { label: 'Interested & Add me', value: '1' },
          { label: 'Drop an Email Only', value: '2' },
          { label: 'Not Interested', value: '3' },
          { label: 'Busy / Unreachable', value: '4' },
          { label: 'Wrong / Incorrect Number', value: '5' },
          { label: 'Disconnected the call', value: '6' },
          { label: 'Out of station, call later', value: '7' },
          { label: 'Already taking from others', value: '8' },
          { label: 'Not Doing EXIM Business', value: '9' },
          { label: 'Small Business', value: '10' },
          { label: 'Leave a Comment', value: '11' },
          { label: 'Did not pick', value: '12' },
     ]);

     const [leadInfo, setLeadInfo] = useState({ fullName: '', companyName: '', address: '', city: '', state: '', email: '', mobile1: '', mobile2: '', status: '', businessType: '', businessVolume: '', source: '', comment: '', later: '' });

     const reload = false;

     async function handleUploadLead(e) {
          if (e) { // add?
               e.preventDefault();
               //      e.persist();
          }
          console.log(leadInfo);
          const requestOptions = {
               mode: 'cors',
               method: 'POST',
               headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Origin': process.env.PUBLIC_URL },
               body: new URLSearchParams({ ...leadInfo, userID: (cookie.load('UserID', { doNotParse: true }) ?? '') })
          }
          await fetch('http://localhost:3000/api/upload-lead', requestOptions)
               .then(function (response) {
                    if (response.statusText === 'Unauthorized') {
                         return 'Unauthorized';
                    }
                    else {
                         return response.json();
                    }
               }).then(function (result) {
                    if (result.success === true) {
                         return;
                    }
                    else {
                         setLoading(false);
                         Timer(7000, result.message, result.success);
                         return;
                    }
               }).catch(function (params) {
                    setLoading(false);
                    Timer(7000, ' ' + params, false);
                    return;
               });
          return;
     }

     return <div style={{ width: '100%', height: '100%', backgroundColor: '#F4F5F7', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <CustomCard>
               <Form style={{ fontFamily: 'monospace', color: 'black', textAlign: 'start', marginBottom: '10px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                         <CustomLabel text={'Contact Lead'} />
                    </div>
                    <CustomDivider />
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>

                         <CustomDropDown label={'Select Source'} handleChange={(selectedOption) => { setLeadInfo((latestLeadInfo) => { return { ...latestLeadInfo, source: selectedOption.value } }); }} list={source} />


                         <div style={{ width: '7.5%' }} />
                         <CustomDropDown label={'Select Business Type'} handleChange={(selectedOption) => { setLeadInfo((latestLeadInfo) => { return { ...latestLeadInfo, businessType: selectedOption.value } }); }} list={businessType} />

                    </div>
                    <CustomDropDown label={'Select Business Volume'} handleChange={(selectedOption) => { setLeadInfo((latestLeadInfo) => { return { ...latestLeadInfo, businessVolume: selectedOption.value } }); }} list={businessVolume} />
                    <CustomDropDown label={'Select Feedback'} handleChange={(selectedOption) => { setLeadInfo((latestLeadInfo) => { return { ...latestLeadInfo, status: selectedOption.value } }); }} list={feedback} />
                    {leadInfo.status === '11' ? <CustomTextInput placeholder={'Enter Comment'} value={leadInfo.comment} onTextChange={(value) => { setLeadInfo((latestLeadInfo) => { return { ...latestLeadInfo, comment: value } }); }} inputType={'number'} /> : null}

                    {leadInfo.status === '7' ? <label style={{
                         width: 'auto',
                         fontSize: '12px',
                         fontWeight: 'bold',
                         letterSpacing: 0.5,
                         color: 'black',
                         display: 'block',
                         textAlign: 'center',
                         marginBottom: '10px',
                         marginTop: '10px'
                    }} >
                         You will have to call this client again on {expiryDate.split(' 00:00:00')[0]}.
                    </label> : null}
                    <CustomTextInput placeholder={'Enter Full Name'} value={leadInfo.fullName} onTextChange={(value) => { setLeadInfo((latestLeadInfo) => { return { ...latestLeadInfo, fullName: value } }); }} inputType={'text'} />
                    <CustomTextInput placeholder={'Enter Company Name'} value={leadInfo.companyName} onTextChange={(value) => { setLeadInfo((latestLeadInfo) => { return { ...latestLeadInfo, companyName: value } }); }} inputType={'text'} />
                    <CustomTextInput placeholder={'Enter Address Name'} value={leadInfo.address} onTextChange={(value) => { setLeadInfo((latestLeadInfo) => { return { ...latestLeadInfo, address: value } }); }} inputType={'text'} />
                    <CustomTextInput placeholder={'Enter City Name'} value={leadInfo.city} onTextChange={(value) => { setLeadInfo((latestLeadInfo) => { return { ...latestLeadInfo, city: value } }); }} inputType={'text'} />
                    <CustomTextInput placeholder={'Enter State Name'} value={leadInfo.state} onTextChange={(value) => { setLeadInfo((latestLeadInfo) => { return { ...latestLeadInfo, state: value } }); }} inputType={'text'} />
                    <CustomTextInput placeholder={'Enter Email Address'} value={leadInfo.email} onTextChange={(value) => { setLeadInfo((latestLeadInfo) => { return { ...latestLeadInfo, email: value } }); }} inputType={'text'} />
                    <CustomTextInput placeholder={'Enter Mobile'} value={leadInfo.mobile1} onTextChange={(value) => { setLeadInfo((latestLeadInfo) => { return { ...latestLeadInfo, mobile1: value } }); }} inputType={'number'} />
                    <CustomTextInput placeholder={'Enter Alternate Mobile'} value={leadInfo.mobile2} onTextChange={(value) => { setLeadInfo((latestLeadInfo) => { return { ...latestLeadInfo, mobile2: value } }); }} inputType={'number'} />

                    <CustomButton onClick={handleUploadLead} text={'Save'} loading={loading} />
               </Form>
          </CustomCard>
     </div>
}

export default CreateDeviceScreen;