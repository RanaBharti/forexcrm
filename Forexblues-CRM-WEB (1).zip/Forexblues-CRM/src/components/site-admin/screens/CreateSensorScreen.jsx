import React, { useEffect, useState } from "react";
import cookie from 'react-cookies';
import { Form } from "react-bootstrap";
import CustomLabel from "../components/CustomLabel";
import CustomTextInput from "../components/CustomTextInput";
import CustomAlert from "../components/CustomAlert";
import CustomButton from "../components/CustomButton";
import CustomCard from "../components/CustomCard";
import CustomDivider from "../components/CustomDivider";
import CustomDropDown from "../components/CustomDropDown";
import CustomMultiDropDown from "../components/CustomMultiDropDown";
import { FormControlLabel, Radio, RadioGroup } from "@material-ui/core";

const resultTypeList = [
     { label: 'Logic', value: 'logic' },
     { label: 'Value', value: 'value' },
     { label: 'Percentage', value: 'percentage' },
     { label: 'String', value: 'string' },
     { label: 'Relative', value: 'relative' },
     { label: 'Absolute', value: 'absolute' }]

const sensorTypeList = [
     { label: 'Battery', value: 'batt' },
     { label: 'Digital Input', value: 'di' },
     { label: 'Digital Output', value: 'do' },
     { label: 'Driver Assign', value: 'da' },
     { label: 'Engine Hours', value: 'engh' },
     { label: 'Fuel Level', value: 'fuel' },
     { label: 'Fuel Level Sum Up', value: 'fuelsumup' },
     { label: 'Fuel Consumption', value: 'fuelcons' },
     { label: 'GSM Level', value: 'gsm' },
     { label: 'GPS Level', value: 'gps' },
     { label: 'Ignition (ACC)', value: 'acc' },
     { label: 'Odometer', value: 'odo' },
     { label: 'Passenger Assign', value: 'pa' },
     { label: 'Temperature', value: 'temp' },
     { label: 'Trailer Assign', value: 'ta' },
     { label: 'Custom', value: 'cust' }]

const parameterList = [{ label: 'acc', value: 'acc' }, { label: 'io239', value: 'io239' }]


const CreateSensorScreen = props => {
     const [alertInfo, setAlertInfo] = useState({ visibility: false, type: 'danger', message: 'Error: Email and password cannot be empty.' });
     const [isCalibration, setIsCalibration] = useState(true);
     const [deviceModelList, setDeviceModelList] = useState([]);
     const [deviceList, setDeviceList] = useState([]);
     const [sensorInfo, setSensorInfo] = useState({
          active: true, isModel: true, imei: '', model: '', name: '', type: '', param: '', result_type: '', text_1: '', text_0: '', units: '', lv: '', hv: '', acc_ignore: '', formula: '', calibration: [], dictionary: []
     });
     const [setXY, setSetXY] = useState({ x: '', y: '' });
     const [setValueText, setSetValueText] = useState({ value: '', text: '' });

     const [loading, setLoading] = useState(false);
     const reload = false;

     function Timer(time, message, type) {
          setAlertInfo({ visibility: true, type: type, message: message });
          setInterval(() => {
               setAlertInfo({ visibility: false, type: type, message: '' });
          }, time);
     }

     function handleRegisterDevice(e) {
          console.log(sensorInfo);
          if (e) { // add?
               e.preventDefault();
          }
          if (!sensorInfo.result_type || !sensorInfo.param || !sensorInfo.type) {
               Timer(5000, 'Kindly fill all the fields.', false);
          }
          else {
               setLoading(true);

               const resultData = { ...sensorInfo, calibration: JSON.stringify(sensorInfo.calibration), dictionary: JSON.stringify(sensorInfo.dictionary) };
               const requestOptions = {
                    mode: 'cors',
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Origin': 'http://165.232.176.240/' },
                    body: new URLSearchParams({ ...resultData, userID: (cookie.load('UserID', { doNotParse: true }) ?? '') })
               };
               if (resultData.isModel) {

                    fetch('http://165.232.176.240/api/create-sensor-tracker', requestOptions)
                         .then(function (response) {
                              if (response.statusText === 'Unauthorized') {
                                   return 'Unauthorized';
                              }
                              else {
                                   return response.json();
                              }
                         }).then(function (result) {
                              if (result.success === true) {
                                   setLoading(false);
                                   Timer(7000, `Sensor created successfully for ${sensorInfo.name}`, result.success);
                                   setSensorInfo({
                                        active: true, isModel: true, imei: '', model: '', name: '', type: '', param: '', result_type: '', text_1: '', text_0: '', units: '', lv: '', hv: '', acc_ignore: '', formula: '', calibration: [], dictionary: []
                                   });
                              }
                              else {
                                   setLoading(false);
                                   Timer(7000, result.message, result.success);
                              }
                         }).catch(function (params) {
                              setLoading(false);
                              Timer(7000, ' ' + params, false);
                         });


               }
               else {
                    fetch('http://165.232.176.240/api/create-sensor', requestOptions)
                         .then(function (response) {
                              if (response.statusText === 'Unauthorized') {
                                   return 'Unauthorized';
                              }
                              else {
                                   return response.json();
                              }
                         }).then(function (result) {
                              if (result.success === true) {
                                   setLoading(false);
                                   Timer(7000, `Sensor created successfully for ${sensorInfo.name}`, result.success);
                                   setSensorInfo({
                                        active: true, isModel: true, imei: '', model: '', name: '', type: '', param: '', result_type: '', text_1: '', text_0: '', units: '', lv: '', hv: '', acc_ignore: '', formula: '', calibration: [], dictionary: []
                                   });
                              }
                              else {
                                   setLoading(false);
                                   Timer(7000, result.message, result.success);
                              }
                         }).catch(function (params) {
                              setLoading(false);
                              Timer(7000, ' ' + params, false);
                         });
               }
          }

     }

     function fetchAllDevicesModel() {
          const requestOptions = {
               mode: 'cors',
               method: 'POST',
               headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Origin': 'http://165.232.176.240/' },
               body: new URLSearchParams({ adminID: (cookie.load('UserID', { doNotParse: true }) ?? '') })
          };
          fetch('http://165.232.176.240/api/devices-model-list', requestOptions)
               .then(function (response) {
                    if (response.statusText === 'Unauthorized') {
                         return 'Unauthorized';
                    }
                    else {
                         return response.json();
                    }
               }).then(function (result) {

                    const deviceModelList = [];
                    result.forEach(element => {
                         deviceModelList.push({ label: `${element.company} - ${element.model}`, value: element._id });
                    });
                    setDeviceModelList(deviceModelList);
               }).catch(function (params) {
                    setDeviceModelList([]);
                    Timer(7000, ' ' + params, false);
               });
     }

     function fetchAllDevices() {
          const requestOptions = {
               mode: 'cors',
               method: 'POST',
               headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Origin': 'http://165.232.176.240/' },
               body: new URLSearchParams({ adminID: (cookie.load('UserID', { doNotParse: true }) ?? '') })
          };
          fetch('http://165.232.176.240/api/admin-devices', requestOptions)
               .then(function (response) {
                    if (response.statusText === 'Unauthorized') {
                         return 'Unauthorized';
                    }
                    else {
                         return response.json();
                    }
               }).then(function (result) {

                    const deviceList = [];
                    result.forEach(element => {
                         deviceList.push({ label: `${element.imei} - ${element.name}`, value: element.imei });
                    });
                    setDeviceList(deviceList);
               }).catch(function (params) {
                    setDeviceList([]);
                    Timer(7000, ' ' + params, false);
               });
     }

     useEffect(() => {
          fetchAllDevicesModel();
          fetchAllDevices();
     }, [reload]);

     return <div style={{ width: '100%', height: '100%', backgroundColor: '#F4F5F7', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>

          <CustomCard>
               <Form style={{ fontFamily: 'monospace', color: 'black', textAlign: 'start', marginBottom: '10px' }}>

                    <CustomLabel text={'Create a sensor.'} />
                    <CustomDivider />
                    <CustomTextInput placeholder={'Enter Sensor Name'} value={sensorInfo.name} onTextChange={(value) => { setSensorInfo((latestSensorInfo) => { return { ...latestSensorInfo, name: value } }); }} inputType={'text'} />
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                         <CustomDropDown label={'Sensor Type'} handleChange={(selectedOption) => { setSensorInfo((latestSensorInfo) => { return { ...latestSensorInfo, type: selectedOption.value } }); }} list={sensorTypeList} />
                         <div style={{ width: '7.5%' }} />
                         <CustomDropDown label={'Sensor Parameter'} handleChange={(selectedOption) => { setSensorInfo((latestSensorInfo) => { return { ...latestSensorInfo, param: selectedOption.value } }); }} list={parameterList} />
                    </div>

                    <CustomDropDown label={'Result Type'} handleChange={(selectedOption) => { setSensorInfo((latestSensorInfo) => { return { ...latestSensorInfo, result_type: selectedOption.value } }); }} list={resultTypeList} />

                    <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, color: 'grey', textAlign: 'start', marginBottom: '5px' }}>Sensor For</Form.Label>
                    <RadioGroup aria-label="anonymous" name="anonymous" value={sensorInfo.isModel ? 'Tracker' : 'Device'} row style={{ alignItems: 'center', display: 'flex', justifyContent: 'center' }} onChange={(event) => { setSensorInfo((latestSensorInfo) => { return { ...latestSensorInfo, isModel: event.target.value === 'Tracker' } }); }}>
                         <FormControlLabel style={{ fontSize: '14px', letterSpacing: 0.75, color: 'grey', textAlign: 'start', marginBottom: '5px' }} value="Tracker" control={<Radio />} label="Tracker" />
                         <FormControlLabel style={{ fontSize: '14px', letterSpacing: 0.75, color: 'grey', textAlign: 'start', marginBottom: '5px' }} value="Device" control={<Radio />} label="Device" />
                    </RadioGroup>
                    {sensorInfo.isModel ? <CustomDropDown label={'Select Tracker Model'} handleChange={(selectedOption) => { setSensorInfo((latestSensorInfo) => { return { ...latestSensorInfo, model: selectedOption.value } }); }} list={deviceModelList} /> : <CustomDropDown label={'Select Device'} handleChange={(selectedOption) => { setSensorInfo((latestSensorInfo) => { return { ...latestSensorInfo, imei: selectedOption.value } }); }} list={deviceList} />}
                    {sensorInfo.result_type === 'logic' ? <CustomTextInput placeholder={'Enter Result if 0'} value={sensorInfo.text_0} onTextChange={(value) => { setSensorInfo((latestSensorInfo) => { return { ...latestSensorInfo, text_0: value } }); }} inputType={'text'} /> : null}
                    {sensorInfo.result_type === 'logic' ? <CustomTextInput placeholder={'Enter Result if 1'} value={sensorInfo.text_1} onTextChange={(value) => { setSensorInfo((latestSensorInfo) => { return { ...latestSensorInfo, text_1: value } }); }} inputType={'text'} /> : null}
                    {sensorInfo.result_type === 'value' ? <CustomTextInput placeholder={'Enter Unit of Measurement'} value={sensorInfo.units} onTextChange={(value) => { setSensorInfo((latestSensorInfo) => { return { ...latestSensorInfo, units: value } }); }} inputType={'text'} /> : null}
                    {sensorInfo.result_type === 'percentage' ? <CustomTextInput placeholder={'Highest Value'} value={sensorInfo.hv} onTextChange={(value) => { setSensorInfo((latestSensorInfo) => { return { ...latestSensorInfo, hv: value } }); }} inputType={'text'} /> : null}
                    {sensorInfo.result_type === 'percentage' ? <CustomTextInput placeholder={'Lowest Value'} value={sensorInfo.lv} onTextChange={(value) => { setSensorInfo((latestSensorInfo) => { return { ...latestSensorInfo, lv: value } }); }} inputType={'text'} /> : null}
                    {(sensorInfo.result_type === 'value' || sensorInfo.result_type === 'relative' || sensorInfo.result_type === 'absolute') ? <CustomTextInput placeholder={'Formula'} value={sensorInfo.formula} onTextChange={(value) => { setSensorInfo((latestSensorInfo) => { return { ...latestSensorInfo, formula: value } }); }} inputType={'text'} /> : null}
                    <CustomButton onClick={handleRegisterDevice} text={'Create Device'} loading={loading} />
               </Form>
          </CustomCard>
          {sensorInfo.result_type === 'value' ? <div style={{ width: '2.5%' }} /> : null}
          {sensorInfo.result_type === 'value' ? <CustomCard>
               <Form style={{ fontFamily: 'monospace', color: 'black', textAlign: 'start', marginBottom: '10px' }}>

                    <CustomLabel text={'Calibration OR Dictionary'} />
                    <CustomDivider />

                    <RadioGroup aria-label="anonymous" name="anonymous" value={isCalibration ? 'Calibration' : 'Dictionary'} row style={{ alignItems: 'center', display: 'flex', justifyContent: 'center' }} onChange={(event) => { setIsCalibration(event.target.value === 'Calibration'); }}>
                         <FormControlLabel style={{ fontSize: '14px', letterSpacing: 0.75, color: 'grey', textAlign: 'start', marginBottom: '5px' }} value="Calibration" control={<Radio />} label="Calibration" />
                         <FormControlLabel style={{ fontSize: '14px', letterSpacing: 0.75, color: 'grey', textAlign: 'start', marginBottom: '5px' }} value="Dictionary" control={<Radio />} label="Dictionary" />
                    </RadioGroup>

                    {isCalibration ? <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                         <CustomTextInput placeholder={'Enter X'} value={setXY.x} onTextChange={(value) => { setSetXY((latestXY) => { return { ...latestXY, x: value } }); }} inputType={'text'} />
                         <CustomTextInput placeholder={'Enter Y'} value={setXY.y} onTextChange={(value) => { setSetXY((latestXY) => { return { ...latestXY, y: value } }); }} inputType={'text'} />
                    </div> : <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                         <CustomTextInput placeholder={'Enter Value'} value={setValueText.value} onTextChange={(value) => { setSetValueText((latestValueText) => { return { ...latestValueText, value: value } }); }} inputType={'text'} />
                         <CustomTextInput placeholder={'Enter Text'} value={setValueText.text} onTextChange={(value) => { setSetValueText((latestValueText) => { return { ...latestValueText, text: value } }); }} inputType={'text'} />
                    </div>}
                    <CustomButton onClick={(e) => {
                         if (e) { // add?
                              e.preventDefault();
                         }
                         if (isCalibration) {
                              setSensorInfo((latestSensorInfo) => { return { ...latestSensorInfo, calibration: [...latestSensorInfo.calibration, setXY] } });
                              setSetXY({ x: '', y: '' });
                         }
                         else {
                              setSensorInfo((latestSensorInfo) => { return { ...latestSensorInfo, dictionary: [...latestSensorInfo.dictionary, setValueText] } });
                              setSetValueText({ value: '', text: '' });
                         }
                    }} text={isCalibration ? 'Add Calibration' : 'Add Dictionary'} loading={loading} />
                    <div style={{ display: 'flex', marginTop: '5%' }}>
                         <div style={{
                              flex: '50%'
                         }}>
                              <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, textAlign: 'center', width: '100%', marginBottom: '5px' }}>{isCalibration ? 'X' : 'Value'}</Form.Label>
                         </div>
                         <div style={{
                              flex: '50%'
                         }}>
                              <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, textAlign: 'center', width: '100%', marginBottom: '5px' }}>{isCalibration ? 'Y' : 'Text'}</Form.Label>
                         </div>
                    </div>
                    <div style={{ height: '30vh', overflow: 'auto' }}>

                         {isCalibration ? sensorInfo.calibration.map((element) => {
                              return <div style={{ display: 'flex' }}>
                                   <div style={{
                                        flex: '50%'
                                   }}>
                                        <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, textAlign: 'center', width: '100%', marginBottom: '5px' }}>{element.x}</Form.Label>
                                   </div>
                                   <div style={{
                                        flex: '50%'
                                   }}>
                                        <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, textAlign: 'center', width: '100%', marginBottom: '5px' }}>{element.y}</Form.Label>
                                   </div>
                              </div>
                         }) : sensorInfo.dictionary.map((element) => {
                              return <div style={{ display: 'flex' }}>
                                   <div style={{
                                        flex: '50%'
                                   }}>
                                        <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, textAlign: 'center', width: '100%', marginBottom: '5px' }}>{element.value}</Form.Label>
                                   </div>
                                   <div style={{
                                        flex: '50%'
                                   }}>
                                        <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, textAlign: 'center', width: '100%', marginBottom: '5px' }}>{element.text}</Form.Label>
                                   </div>
                              </div>
                         })}
                    </div>
               </Form>
          </CustomCard> : null}

          <CustomAlert info={alertInfo} />
     </div >
}

export default CreateSensorScreen;