import React, { useState } from "react";
import { Form } from "react-bootstrap";
import CustomLabel from "../components/CustomLabel";
import CustomTextInput from "../components/CustomTextInput";
import CustomAlert from "../components/CustomAlert";
import CustomButton from "../components/CustomButton";
import CustomCard from "../components/CustomCard";
import CustomDivider from "../components/CustomDivider";
import cookie from 'react-cookies';

const CreateTrackerScreen = props => {
     const [alertInfo, setAlertInfo] = useState({ visibility: false, type: 'danger', message: 'Error: Email and password cannot be empty.' });
     const [modelInfo, setModelInfo] = useState({
          active: true, companyName: '',
          model: '', lock: '', unlock: '', port: ''
     });

     const [loading, setLoading] = useState(false);
     const reload = false;

     function Timer(time, message, type) {
          setAlertInfo({ visibility: true, type: type, message: message });
          setInterval(() => {
               setAlertInfo({ visibility: false, type: type, message: '' });
          }, time);
     }

     function handleRegisterDevice(e) {
          console.log(modelInfo);
          if (e) { // add?
               e.preventDefault();
          }
          if (!modelInfo.companyName || !modelInfo.model || !modelInfo.port) {
               Timer(5000, 'Kindly fill all the fields.', false);
          }
          else {
               setLoading(true);
               const requestOptions = {
                    mode: 'cors',
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Origin': 'http://165.232.176.240/' },
                    body: new URLSearchParams({ ...modelInfo, userID: (cookie.load('UserID', { doNotParse: true }) ?? '') })
               };
               fetch('http://165.232.176.240/api/create-device-model', requestOptions)
                    .then(function (response) {
                         if (response.statusText === 'Unauthorized') {
                              return 'Unauthorized';
                         }
                         else {
                              return response.json();
                         }
                    }).then(function (result) {
                         if (result.success === true) {
                              setLoading(false);
                              Timer(7000, `User created successfully for ${modelInfo.companyName} ${modelInfo.model}.`, result.success);
                              setModelInfo({
                                   active: true, companyName: '',
                                   model: '', lock: '', unlock: '', port: ''
                              });
                         }
                         else {
                              setLoading(false);
                              Timer(7000, result.message, result.success);
                         }
                    }).catch(function (params) {
                         setLoading(false);
                         Timer(7000, ' ' + params, false);
                    });
          }
     }

     return <div style={{ width: '100%', height: '100%', backgroundColor: '#F4F5F7', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <CustomCard>
               <Form style={{ fontFamily: 'monospace', color: 'black', textAlign: 'start', marginBottom: '10px' }}>
                    <CustomLabel text={'Create a tracker.'} />
                    <CustomDivider />
                    <CustomTextInput placeholder={'Enter Company Name'} value={modelInfo.companyName} onTextChange={(value) => { setModelInfo((latestModelInfo) => { return { ...latestModelInfo, companyName: value } }); }} inputType={'text'} />
                    <CustomTextInput placeholder={'Enter Model'} value={modelInfo.model} onTextChange={(value) => { setModelInfo((latestModelInfo) => { return { ...latestModelInfo, model: value } }); }} inputType={'text'} />
                    <CustomTextInput placeholder={'Enter Lock Command'} value={modelInfo.lock} onTextChange={(value) => { setModelInfo((latestModelInfo) => { return { ...latestModelInfo, lock: value } }); }} inputType={'text'} />
                    <CustomTextInput placeholder={'Enter Unlock Command'} value={modelInfo.unlock} onTextChange={(value) => { setModelInfo((latestModelInfo) => { return { ...latestModelInfo, unlock: value } }); }} inputType={'text'} />
                    <CustomTextInput placeholder={'Enter Port'} value={modelInfo.port} onTextChange={(value) => { setModelInfo((latestModelInfo) => { return { ...latestModelInfo, port: value } }); }} inputType={'number'} />
                    <CustomButton onClick={handleRegisterDevice} text={'Create Tracker'} loading={loading} />
               </Form>
          </CustomCard>
          <CustomAlert info={alertInfo} />
     </div>
}

export default CreateTrackerScreen;