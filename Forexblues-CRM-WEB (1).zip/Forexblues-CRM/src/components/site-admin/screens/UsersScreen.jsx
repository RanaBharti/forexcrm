import React, { useEffect, useState, useMemo } from "react";
import cookie from 'react-cookies';
import Spinner from "react-bootstrap/Spinner";
import CustomAlert from "../components/CustomAlert";
import CustomLabel from "../components/CustomLabel";
import { Container, Button, lightColors, darkColors } from 'react-floating-action-button'
import { FaPlus } from "react-icons/fa";

const columns = [
     { name: 'name', header: 'Name', minWidth: 50, defaultFlex: 2 },
     { name: 'age', header: 'Age', maxWidth: 1000, defaultFlex: 1 },
];

const gridStyle = { minHeight: 550 };

const dataSource = [
     { id: 1, name: 'John McQueen', age: 35 },
     { id: 2, name: 'Mary Stones', age: 25 },
     { id: 3, name: 'Robert Fil', age: 27 },
     { id: 4, name: 'Roger Robson', age: 81 },
     { id: 5, name: 'Billary Konwik', age: 18 },
     { id: 6, name: 'Bob Martin', age: 18 },
     { id: 7, name: 'Matthew Richardson', age: 54 },
     { id: 8, name: 'Ritchie Peterson', age: 54 },
     { id: 9, name: 'Bryan Martin', age: 40 },
     { id: 10, name: 'Mark Martin', age: 44 },
     { id: 11, name: 'Michelle Sebastian', age: 24 },
     { id: 12, name: 'Michelle Sullivan', age: 61 },
     { id: 13, name: 'Jordan Bike', age: 16 },
     { id: 14, name: 'Nelson Ford', age: 34 },
     { id: 15, name: 'Tim Cheap', age: 3 },
     { id: 16, name: 'Robert Carlson', age: 31 },
     { id: 17, name: 'Johny Perterson', age: 40 },
];

const UsersScreen = props => {
     const [alertInfo, setAlertInfo] = useState({ visibility: false, type: 'danger', message: '' });

     const [userList, setUserList] = useState(null);

     const reload = false;

     function Timer(time, message, type) {
          setAlertInfo({ visibility: true, type: type, message: message });
          setInterval(() => {
               setAlertInfo({ visibility: false, type: type, message: '' });
          }, time);
     }

     function fetchAllUsers() {
          const requestOptions = {
               mode: 'cors',
               method: 'POST',
               headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Origin': 'http://165.232.176.240/' },
               body: new URLSearchParams({ adminID: (cookie.load('UserID', { doNotParse: true }) ?? '') })
          };
          fetch('http://165.232.176.240/api/admin-users', requestOptions)
               .then(function (response) {
                    if (response.statusText === 'Unauthorized') {
                         return 'Unauthorized';
                    }
                    else {
                         return response.json();
                    }
               }).then(function (result) {
                    setUserList(result);
               }).catch(function (params) {
                    setUserList([]);
                    Timer(7000, ' ' + params, false);
               });
     }

     useEffect(() => {
          fetchAllUsers();
     }, [reload])

     return <div style={{ width: '100%', height: '100%', backgroundColor: '#F4F5F7', position: 'absolute', padding: '10%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>

          {userList ? <div style={{ overflow: "scroll", width: '100%', height: '100%', position: 'absolute', padding: '1%' }}>
               <CustomLabel text={'All Users'} />

               {/* <TableContainer component={Paper}>

               <div style={{ width: '100%', height: 'auto', maxHeight: '80%', backgroundColor: '#FFFFFF', padding: '2.5%', borderRadius: '15px', overflow: 'scroll' }}>
                    <Table aria-label="simple table" >

                              <TableHead >
                                   <TableRow>
                                        <TableCell  style={{ border: "none",
  boxShadow: "none"}}>Name</TableCell>
                                        <TableCell>Email</TableCell>
                                        <TableCell>Mobile</TableCell>

                                        <TableCell>Active</TableCell>
                                        <TableCell>Login Time</TableCell>
                                        <TableCell>Actions</TableCell>
                                   </TableRow>
                              </TableHead>
                         <TableBody>
                              {userList.map((element) => (
                                   <TableRow key={element.username}>
                                        <TableCell component="th" scope="row">
                                             {element.name}
                                        </TableCell>
                                        <TableCell>{element.email}</TableCell>
                                        <TableCell>{element.mobile}</TableCell>

                                        <TableCell>{element.active === true ? 'Yes' : 'No'}</TableCell>

                                        <TableCell>{element.login_date}</TableCell>
                                        <TableCell>
                                             <FaSearchLocation size={18} class="center" style={{ marginLeft: 5, marginRight: 5, color: 'blue' }} />
                                             <FaEdit size={18} class="center" style={{ marginLeft: 5, marginRight: 5, color: 'blue' }} />
                                             <FaTrashAlt size={18} class="center" style={{ marginLeft: 5, marginRight: 5, color: 'blue' }} />
                                        </TableCell>
                                   </TableRow>
                              ))}
                         </TableBody>
                    </Table>
                    </div>
               </TableContainer> */}
          </div> :
               <Spinner animation="border" role="status">
                    <span className="visually-hidden">Loading...</span>
               </Spinner>}
          <CustomAlert info={alertInfo} />
          <Container style={{ padding: 0 }}>
               <Button
                    rotate={false}
                    styles={{ backgroundColor: darkColors.blue, color: lightColors.white }}
                    onClick={() => { }} ><FaPlus size={18} class="center" /></Button>
          </Container>
     </div>
}

export default UsersScreen;