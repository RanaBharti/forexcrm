import React, { useEffect, useState } from "react";
import cookie from 'react-cookies';
import Spinner from "react-bootstrap/Spinner";
import { FaEdit, FaSearchLocation, FaTrashAlt } from 'react-icons/fa';
import { Form } from "react-bootstrap";
import CustomAlert from "../components/CustomAlert";
import CustomLabel from "../components/CustomLabel";
import CustomButton from "../components/CustomButton";

const ViewAllDevicesScreen = ({ Timer, addDevice }) => {
     const [deviceList, setDeviceList] = useState([]);


     function fetchAllUsers() {
          const requestOptions = {
               mode: 'cors',
               method: 'POST',
               headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Origin': 'http://165.232.176.240/' },
               body: new URLSearchParams({ userID: (cookie.load('UserID', { doNotParse: true }) ?? ''), status: '1' })
          };
          fetch('http://localhost:3000/api/user-leads', requestOptions)
               .then(function (response) {
                    if (response.statusText === 'Unauthorized') {
                         return 'Unauthorized';
                    }
                    else {
                         return response.json();
                    }
               }).then(function (result) {
                    setDeviceList(result.data);
               }).catch(function (params) {
                    Timer(7000, ' ' + params, false);
               });
     }

     useEffect(() => {
          fetchAllUsers();
     })


     function save(filename, data) {
          const blob = new Blob([data]);
          if (window.navigator.msSaveOrOpenBlob) {
               window.navigator.msSaveBlob(blob, filename + '.html');
          }
          else {
               const elem = window.document.createElement('a');
               elem.href = window.URL.createObjectURL(blob);
               elem.download = filename + '.csv';
               document.body.appendChild(elem);
               elem.click();
               document.body.removeChild(elem);
          }
     }


     return <div style={{ width: '100%', height: '100%', backgroundColor: '#F4F5F7', padding: '1%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>

          {deviceList ? <div style={{ overflow: "scroll", width: '100%', height: '100%', padding: '1%' }}>
               <div style={{ fontSize: '24px', width: '100%', marginBottom: '5px', display: 'flex', alignItems: 'center', marginBottom: '15px' }}>
                    <Form.Label style={{ fontSize: '24px', letterSpacing: 0.75, textAlign: 'start', width: '80%', height: 'auto' }}>Demo Leads</Form.Label>

                    <div style={{ fontSize: '24px', letterSpacing: 0.75, textAlign: 'start', width: '20%', marginBottom: '5px' }}>
                         <CustomButton onClick={() => {
                              var finalVal = '';

                              for (var i = 0; i < deviceList.length; i++) {
                                  var value = deviceList[i];
                              
                                  for (var j = 0; j < value.length; j++) {
                                      var innerValue =  value[j]===null?'':value[j].toString();
                                      var result = innerValue.replace(/"/g, '""');
                                      if (result.search(/("|,|\n)/g) >= 0)
                                          result = '"' + result + '"';
                                      if (j > 0)
                                          finalVal += ',';
                                      finalVal += result;
                                  }
                              
                                  finalVal += '\n';
                              }
                              console.log(finalVal);
                              save('Data', finalVal);
                         }} text={'Download in Excel'} loading={false} />
                    </div>
               </div>


               <div style={{
                    backgroundColor: 'white',
                    padding: '5px',
                    paddingLeft: '10px',
                    paddingRight: '10px',
                    borderRadius: '5px',
                    boxShadow: '1px 1px 1px 1px rgba(0, 0, 0, 0.2)',
                    marginBottom: '5px'
               }}>
                    <Form.Label style={{ fontSize: '16px', letterSpacing: 0.75, textAlign: 'start', fontWeight: 'bold', width: '18%', marginBottom: '5px', fontFamily: 'serif' }}>Name</Form.Label>
                    <Form.Label style={{ fontSize: '16px', fontWeight: 'bold', letterSpacing: 0.75, textAlign: 'start', width: '18%', marginBottom: '5px', fontFamily: 'serif' }}>Company Name</Form.Label>
                    <Form.Label style={{ fontSize: '16px', letterSpacing: 0.75, fontWeight: 'bold', textAlign: 'start', width: '18%', marginBottom: '5px', fontFamily: 'serif' }}>Address</Form.Label>
                    <Form.Label style={{ fontSize: '16px', letterSpacing: 0.75, textAlign: 'start', fontWeight: 'bold', width: '18%', marginBottom: '5px', fontFamily: 'serif' }}>Feedback</Form.Label>
                    <Form.Label style={{ fontSize: '16px', fontWeight: 'bold', letterSpacing: 0.75, textAlign: 'start', width: '18%', marginBottom: '5px', fontFamily: 'serif' }}>Demo Taken</Form.Label>
                    <Form.Label style={{ fontSize: '16px', fontWeight: 'bold', letterSpacing: 0.75, textAlign: 'start', width: '10%', marginBottom: '5px', fontFamily: 'serif' }}>Actions</Form.Label>
               </div>
               {deviceList.map((element) => {
                    return <div style={{
                         backgroundColor: 'white',
                         padding: '5px',
                         paddingLeft: '10px',
                         paddingRight: '10px',
                         boxShadow: '1px 1px 1px 1px rgba(0, 0, 0, 0.2)',

                    }}>
                         <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, textAlign: 'start', width: '18%', marginBottom: '5px' }}>{element.fullName}</Form.Label>
                         <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, textAlign: 'start', width: '18%', marginBottom: '5px' }}>{element.companyName}</Form.Label>
                         <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, textAlign: 'start', width: '18%', marginBottom: '5px' }}>{element.address}</Form.Label>
                         <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, textAlign: 'start', width: '18%', marginBottom: '5px' }}>{
                              // element.feedback[element.feedback.length - 1].feedback
                         }</Form.Label>
                         <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, textAlign: 'start', width: '18%', marginBottom: '5px' }}>{
                              // element.feedback[element.feedback.length - 1].date
                         }</Form.Label>
                         <div style={{ display: 'inline', width: '10%' }}>
                              <FaEdit size={18} class="center" style={{ marginLeft: 5, marginRight: 5, color: 'blue' }} />
                         </div>
                    </div>
               })}
          </div> :
               <Spinner animation="border" role="status">
                    <span className="visually-hidden">Loading...</span>
               </Spinner>}

     </div>
}

export default ViewAllDevicesScreen;