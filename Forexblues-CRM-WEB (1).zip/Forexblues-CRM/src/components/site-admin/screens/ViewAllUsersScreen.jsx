import React, { useEffect, useState } from "react";
import cookie from 'react-cookies';
import Spinner from "react-bootstrap/Spinner";
import { FaEdit, FaSearchLocation, FaTrashAlt } from 'react-icons/fa';
import { Form } from "react-bootstrap";
import CustomButton from "../components/CustomButton";

const ViewAllUsersScreen = ({ Timer, addUser }) => {
     const [userList, setUserList] = useState([]);
     let reload = false;

     return <div style={{ width: '100%', height: '100%', backgroundColor: '#F4F5F7', padding: '1%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>

          {userList ? <div style={{ overflow: "scroll", width: '100%', height: '100%', padding: '1%' }}>
               <div style={{ fontSize: '24px', width: '100%', marginBottom: '5px', display: 'flex', alignItems: 'center', marginBottom: '15px' }}>
                    <Form.Label style={{ fontSize: '24px', letterSpacing: 0.75, textAlign: 'start', width: '80%', height: 'auto' }}>Users</Form.Label>
                    <div style={{ fontSize: '24px', letterSpacing: 0.75, textAlign: 'start', width: '20%', marginBottom: '5px' }}>
                         <CustomButton onClick={() => { addUser(true); }} text={'Create User'} loading={false} />
                    </div>
               </div>


               <div style={{
                    backgroundColor: 'white',
                    padding: '5px',
                    paddingLeft: '10px',
                    paddingRight: '10px',
                    borderRadius: '5px',
                    boxShadow: '1px 1px 1px 1px rgba(0, 0, 0, 0.2)',
                    marginBottom: '5px'
               }}>
                    <Form.Label style={{ fontSize: '16px', letterSpacing: 0.75, textAlign: 'start', fontWeight: 'bold', width: '18%', marginBottom: '5px', fontFamily: 'serif' }}>Name</Form.Label>
                    <Form.Label style={{ fontSize: '16px', fontWeight: 'bold', letterSpacing: 0.75, textAlign: 'start', width: '18%', marginBottom: '5px', fontFamily: 'serif' }}>Email</Form.Label>
                    <Form.Label style={{ fontSize: '16px', letterSpacing: 0.75, fontWeight: 'bold', textAlign: 'start', width: '18%', marginBottom: '5px', fontFamily: 'serif' }}>Mobile</Form.Label>
                    <Form.Label style={{ fontSize: '16px', letterSpacing: 0.75, textAlign: 'start', fontWeight: 'bold', width: '18%', marginBottom: '5px', fontFamily: 'serif' }}>Active</Form.Label>
                    <Form.Label style={{ fontSize: '16px', letterSpacing: 0.75, textAlign: 'start', fontWeight: 'bold', width: '18%', marginBottom: '5px', fontFamily: 'serif' }}>Last Info.</Form.Label>
                    <Form.Label style={{ fontSize: '16px', fontWeight: 'bold', letterSpacing: 0.75, textAlign: 'start', width: '10%', marginBottom: '5px', fontFamily: 'serif' }}>Actions</Form.Label>
               </div>
               {userList.map((element) => {
                    return <div style={{
                         backgroundColor: 'white',
                         padding: '5px',
                         paddingLeft: '10px',
                         paddingRight: '10px',
                         boxShadow: '1px 1px 1px 1px rgba(0, 0, 0, 0.2)',

                    }}>
                         <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, textAlign: 'start', width: '18%', marginBottom: '5px' }}>{element.name}</Form.Label>
                         <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, textAlign: 'start', width: '18%', marginBottom: '5px' }}>{element.email}</Form.Label>
                         <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, textAlign: 'start', width: '18%', marginBottom: '5px' }}>{element.mobile}</Form.Label>
                         <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, textAlign: 'start', width: '18%', marginBottom: '5px' }}>{element.active ? 'Yes' : 'No'}</Form.Label>
                         <Form.Label style={{ fontSize: '14px', letterSpacing: 0.75, textAlign: 'start', width: '18%', marginBottom: '5px' }}>{element.login_date}</Form.Label>
                         <div style={{ display: 'inline', width: '10%' }}>
                              <FaSearchLocation size={18} class="center" style={{ marginLeft: 5, marginRight: 5, color: 'blue' }} />
                              <FaEdit size={18} class="center" style={{ marginLeft: 5, marginRight: 5, color: 'blue' }} />
                              <FaTrashAlt size={18} class="center" style={{ marginLeft: 5, marginRight: 5, color: 'blue' }} />
                         </div>
                    </div>
               })}
          </div> :
               <Spinner animation="border" role="status">
                    <span className="visually-hidden">Loading...</span>
               </Spinner>}

     </div>
}

export default ViewAllUsersScreen;